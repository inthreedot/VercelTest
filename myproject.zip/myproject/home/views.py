from django.shortcuts import render
from django.contrib.auth.decorators import login_required
# from django.http import HttpResponse
# from django.template import loader
from students.models import admittedStudent
from teachers.models import Teacher

# Create your views here.
# Home page
@login_required(login_url='login')
def home(request):
    students = admittedStudent.objects.all()
    total_students = admittedStudent.objects.count()
    teachers  = Teacher.objects.all()
    total_teachers = Teacher.objects.count()

    context = {
        'students': students,
        'total_students': total_students,
        'teachers': teachers,
        'total_teachers': total_teachers,
    }
    return render(request, 'home.html', context)
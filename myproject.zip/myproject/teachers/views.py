from django.shortcuts import render, redirect, get_object_or_404
from teachers.models import Teacher
from django.contrib import messages

# Create your views here.
# Teachers page
def teachers(request):
    teachers = Teacher.objects.all()
    total_count = Teacher.objects.count()

    context = {
        'teachers': teachers,
        'total_count': total_count,
    }
    return render(request, 'teachers.html', context)



# Appoint teacher page
def appoint_teacher(request):
    if request.method == "POST":
        name = request.POST['name']
        dob = request.POST['dob']
        sex = request.POST['sex']
        qualification = request.POST['qualification']
        mobile_number = request.POST['mobile-number']
        alternate_mobile_number = request.POST['alternate-mobile-number']
        pan_number = request.POST['pan-number']
        aadhaar_number = request.POST['aadhaar-number']
        vill_town = request.POST['vill-town']
        post_office = request.POST['post-office']
        police_station = request.POST['police-station']
        district = request.POST['district']
        state = request.POST['state']
        country = request.POST['country']
        pin = request.POST['pin']
        bank_name = request.POST['bank-name']
        account_number = request.POST['account-number']
        branch_name = request.POST['branch-name']
        ifsc = request.POST['ifsc']
        photo = request.POST['photo']
        resume = request.POST['resume']

        if len(name) < 3:
            messages.error(request, 'Please fill the form correctly!')
        else:
            teacher = Teacher(name=name, date_of_birth=dob, sex=sex, qualification=qualification, mobile_number=mobile_number, alternate_mobile_number=alternate_mobile_number, pan_number=pan_number, aadhaar_number=aadhaar_number, village_town=vill_town, post_office=post_office, police_station=police_station,
                              district=district, state=state, country=country, pin_code=pin, bank_name=bank_name, bank_account_number=account_number, bank_branch_name=branch_name, ifsc_code=ifsc, photo=photo, resume=resume)
            teacher.save()
            messages.success(
                request, 'New teacher has been appointed successfully!')

    return render(request, 'appoint_teacher.html')




# Search teacher
def search_teacher(request):
    query = request.GET['teacher']
    if len(query) > 255:
        teachers = Teacher.objects.none()
    else:
        name = Teacher.objects.filter(
            name__icontains=query)
        qualification = Teacher.objects.filter(
            qualification__icontains=query)
        teachers = name.union(qualification)

    count = teachers.count()

    if count == 0:
        messages.warning(request, 'Please enter someting!')

    context = {
        'teachers': teachers,
        'count': count,
    }
    return render(request, 'search_teacher.html', context)
    # return HttpResponse('This is search!')


# Teacher detail
def teacher_detail(request, pk):
    teacher = get_object_or_404(Teacher, pk=pk)
    return render(request, 'teacher_detail.html', {'teacher': teacher})


# Delete teacher
def delete_teacher(request, pk):
    if request.method == 'POST':
        teacher = get_object_or_404(Teacher, pk=pk)
        teacher.delete()
        return redirect('teachers')
    else:
        return redirect('teachers')


# Edit & update teacher
def update_teacher(request, pk):
    teacher = Teacher.objects.get(pk=pk)
    if request.method == 'POST':
        # Get the updated values from the form
        teacher.name = request.POST.get('name')
        teacher.date_of_birth = request.POST.get('dob')
        teacher.sex = request.POST.get('sex')
        teacher.qualification = request.POST.get('qualification')
        teacher.mobile_number = request.POST.get('mobile-number')
        teacher.alternate_mobile_number = request.POST.get(
            'alternate-mobile-number')
        teacher.pan_number = request.POST.get('pan-number')
        teacher.aadhaar_number = request.POST.get('aadhaar-number')
        teacher.village_town = request.POST.get('vill-town')
        teacher.post_office = request.POST.get('post-office')
        teacher.police_station = request.POST.get('police-station')
        teacher.district = request.POST.get('district')
        teacher.state = request.POST.get('state')
        teacher.country = request.POST.get('country')
        teacher.pin = request.POST.get('pin')
        teacher.bank_name = request.POST.get('bank-name')
        teacher.bank_account_number = request.POST.get('account-number')
        teacher.bank_branch_name = request.POST.get('branch-name')
        teacher.ifsc_code = request.POST.get('ifsc')
        teacher.photo = request.POST.get('photo')
        teacher.resume = request.POST.get('resume')
        # Save the updated values to the database
        teacher.save()
        # Redirect back to the student detail page
        return redirect('teacher_detail', pk=teacher.pk)
    # Render the update form
    return render(request, 'update_teacher.html', {'teacher': teacher})

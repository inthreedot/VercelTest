from django.db import models
# import datetime
# import uuid

# Create your models here.

# Teacher Appointment model
class Teacher(models.Model):
    # id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    # id = models.IntegerField(primary_key=True, unique=True, editable=False)
    name = models.CharField(max_length=255)
    sex = models.CharField(max_length=10)
    date_of_birth = models.DateField()
    qualification = models.CharField(max_length=255)
    mobile_number = models.CharField(max_length=20)
    alternate_mobile_number = models.CharField(max_length=20, blank=True)
    pan_number = models.CharField(max_length=20)
    aadhaar_number = models.CharField(max_length=20)
    village_town = models.CharField(max_length=255)
    post_office = models.CharField(max_length=255)
    police_station = models.CharField(max_length=255)
    district = models.CharField(max_length=255)
    state = models.CharField(max_length=255)
    country = models.CharField(max_length=255)
    pin_code = models.CharField(max_length=10)
    bank_name = models.CharField(max_length=255)
    bank_account_number = models.CharField(max_length=255)
    bank_branch_name = models.CharField(max_length=255)
    ifsc_code = models.CharField(max_length=255)
    photo = models.ImageField(upload_to='teacher_photos/')
    resume = models.FileField(upload_to='teacher_resumes/')

    def __str__(self):
        return self.name

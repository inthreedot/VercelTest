from django.urls import path
from . import views

urlpatterns = [
    path('', views.teachers, name='teachers'),
    path('appoint_teacher/', views.appoint_teacher, name='appoint_teacher'),
    path('view_detail/', views.teacher_detail, name='view_detail'),
    path('search_teacher/', views.search_teacher, name='search_teacher'),
    path('teachers_detail/<int:pk>/', views.teacher_detail, name='teacher_detail'),
    path('delete/<int:pk>/', views.delete_teacher, name='delete_teacher'),
    path('update/<int:pk>/', views.update_teacher, name='update_teacher'),
    # path('view_detail/<int:student_id>/', views.viewDetails, name='view_detail'),
]